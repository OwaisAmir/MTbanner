#!/bin/bash

# Set the folder path
FOLDER_PATH="$(pwd)/myfolder"

# Check if the .bashrc file exists in the folder
if [ -e "$FOLDER_PATH/.bashrc" ]; then
    # Copy .bashrc to Termux home directory
    cp "$FOLDER_PATH/.bashrc" $HOME/
    echo "Banner was successfully added"
    echo "Restart your Termux"
    termux-open-url "https://youtube.com/@reset_your_minds?si=3Cx>"

else
    echo "Error :: Banner was not installed. "
    echo "Contact US : https://youtube.com/@reset_your_minds?si=A>"
fi
